package nl.amis.smeetsm.demoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
